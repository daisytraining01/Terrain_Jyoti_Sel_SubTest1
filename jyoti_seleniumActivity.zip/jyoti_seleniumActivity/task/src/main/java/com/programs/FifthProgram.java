package com.programs;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FifthProgram {

	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver", "src/main/java/driver/chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://www.tutorialspoint.com/index.htm");
		
		// Used tagName method to collect the list of items with tagName "a"

		List<WebElement> totalLinkList = driver.findElements(By.tagName("a"));

		System.out.println("Total links on web page are " + totalLinkList.size());

		for (int i = 0; i < totalLinkList.size(); i++) {

			WebElement ele = totalLinkList.get(i);

			String url = ele.getAttribute("href");

			urlVerification(url);
		}
	}

	// The below function verifyLink(String urlLink) verifies any broken links and
	// return the server status.
	public static void urlVerification(String urlLink) throws IOException  {

		
		URL link;
		try {
			
			link = new URL(urlLink);
			HttpURLConnection httpConn = (HttpURLConnection) link.openConnection();
			
			httpConn.setConnectTimeout(2000);
			
			httpConn.connect();
			
			if (httpConn.getResponseCode() == 200) {
				System.out.println(urlLink + " - " + httpConn.getResponseMessage());
			}
				
			if(httpConn.getResponseCode()== 404) {
					 System.out.println(urlLink+" - "+httpConn.getResponseMessage());
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			
			System.out.println("broken url");
		}
		
		
		

	}

}
