package com.programs;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SecondProgram {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "src/main/java/driver/chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/sql/sql_syntax.asp");
		 
	          
		
		driver.manage().window().maximize();     
		
		List<WebElement> irows =   driver.findElements(By.xpath("//*[@id='main']/div[3]/table/tbody/tr"));     
		int iRowsCount = irows.size();     
		List<WebElement> icols =   driver.findElements(By.xpath("//*[@id='main']/div[3]/table/tbody/tr[1]/th"));     
		int iColsCount = icols.size();     
		System.out.println("Selected web table has " +iRowsCount+ " Rows and " +iColsCount+ " Columns");     
		System.out.println();      

		FileOutputStream fos = new FileOutputStream("src/main/java/data/excel.xlsx");                                 

		XSSFWorkbook wkb = new XSSFWorkbook();       
		XSSFSheet sheet1 = wkb.createSheet("sheet1"); 

		for (int i = 1; i <= iRowsCount; i++) {
	        XSSFRow excelRow = sheet1.createRow(i);
	        for (int j = 1; j <= iColsCount; j++) {             
		{           
		if (i==1)       
		{           
		WebElement val= driver.findElement(By.xpath("//*[@id='main']/div[3]/table/tbody/tr["+i+"]/th["+j+"]"));             
		String  a = val.getText();            
		System.out.print(a);                        

		            
		XSSFCell excelCell = excelRow.createCell(j);                  
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                 
		excelCell.setCellValue(a);  

		//wkb.write(fos);       
		}       
		else        
		{           
		WebElement val= driver.findElement(By.xpath("//*[@id='main']/div[3]/table/tbody/tr["+i+"]/td["+j+"]"));             
		String a = val.getText();                    
		System.out.print(a);                            

		            
		XSSFCell excelCell = excelRow.createCell(j);                      
		excelCell.setCellType(XSSFCell.CELL_TYPE_STRING);                   
		excelCell.setCellValue(a);   

		     
		}       
		}               
		System.out.println();     
		}     
		fos.flush();     
		wkb.write(fos);     
		fos.close();     
		}
}

		

}
