package com.programs;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FirstProgram {
	
	
	public static void main(String[] args) throws IOException {
		
		System.setProperty("webdriver.chrome.driver", "src/main/java/driver/chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://demo.guru99.com/test/newtours/register.php");
		
		//a)Select �AUSTRALIA� programmatically from the list box
		Select sel=new Select(driver.findElement(By.name("country")));		   
		   sel.selectByValue("AUSTRALIA");
		
		//b) Before clicking submit fetch the values displayed in each field and print in command line
		   
		   FirstProgram fp=new FirstProgram();
		   
		   WebElement ele1 = driver.findElement(By.name("firstName"));
		   ele1.sendKeys("jyoti");
		   System.out.println(ele1.getAttribute("value"));
		   
		   WebElement ele2 = driver.findElement(By.name("lastName"));
		   ele2.sendKeys("umarji");
		   System.out.println(ele2.getAttribute("value"));
		   
		   WebElement ele3 = driver.findElement(By.name("phone"));
		   ele3.sendKeys("567789900");
		   System.out.println(ele3.getAttribute("value"));
		   
		   WebElement ele4 = driver.findElement(By.name("userName"));
		   ele4.sendKeys("jyoti@gmail.com");
		   System.out.println(ele4.getAttribute("value"));
		   
		   WebElement ele5 = driver.findElement(By.name("address1"));
		   ele5.sendKeys("mg road");
		   System.out.println(ele5.getAttribute("value"));
		   
		   WebElement ele6= driver.findElement(By.name("city"));
		   ele6.sendKeys("banglore");
		   System.out.println(ele6.getAttribute("value"));
		   
		   WebElement ele7 = driver.findElement(By.name("state"));
		   ele7.sendKeys("karanataka");
		   System.out.println(ele7.getAttribute("value"));
		   
		   WebElement ele8 = driver.findElement(By.name("postalCode"));
		   ele8.sendKeys("56003");
		   System.out.println(ele8.getAttribute("value"));
		   
		   WebElement ele9 = driver.findElement(By.id("email"));
		   ele9.sendKeys("jyoti@gmail.com");
		   System.out.println(ele9.getAttribute("value"));
		   
		   
		   WebElement ele10 = driver.findElement(By.name("password"));
		   ele10.sendKeys("password");
		   System.out.println(ele10.getAttribute("value"));
		   
		   WebElement ele11= driver.findElement(By.name("confirmPassword"));
		   ele11.sendKeys("password");
		   System.out.println(ele11.getAttribute("value"));
		   
		   
		    driver.findElement(By.name("submit")).click();
		    
		   System.out.println(driver.getTitle());
		    
		    
		    

	}
	
	
	
	public String readDataFromExcel(int rownum,int columnnum) throws IOException {
		
		String filename="src/main/java/data/input.xlsx";	
		String cellvalue="";
		
		FileInputStream fio=new FileInputStream(filename);
		
		
		XSSFWorkbook workbook=new XSSFWorkbook(fio);//open the workbook
		
		XSSFSheet sheet=workbook.getSheetAt(0);//get the sheet at index 0
		
		Row row=sheet.getRow(rownum);//get the row number
		
		Cell col=row.getCell(columnnum);//get the cell number
		
		if (col.getCellType() == Cell.CELL_TYPE_STRING) {		
			
			 cellvalue=col.getStringCellValue();
			}
			else if(col.getCellType() == Cell.CELL_TYPE_NUMERIC) {
				
			 cellvalue=NumberToTextConverter.toText(col.getNumericCellValue());
			}
			return cellvalue;	    		
	}


}
