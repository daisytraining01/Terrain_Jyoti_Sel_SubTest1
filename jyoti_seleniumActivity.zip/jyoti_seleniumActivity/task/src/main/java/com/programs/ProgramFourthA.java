package com.programs;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ProgramFourthA {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "src/main/java/driver/chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");

		

		try {
			//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobile");
			
			//purposely i added wrong id value to throw NoSuchElementException
			driver.findElement(By.id("id")).sendKeys("mobile");
			
			int i=2/0;
			int []n= {1,3,4,6};
			n[5]=3;
			int n2=Integer.parseInt("ten");
			String s=null;
			s.charAt(1);
		}
		
		catch (NoSuchElementException e) {
			System.out.println("element not found");
     
		}catch (ArithmeticException e) {
			System.out.println("devided by zero exception");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("the array index is not valid to access");
		}catch(NumberFormatException e) {
			System.out.println("number to parse is not correct");
		}catch (NullPointerException e) {
			System.out.println("the string is null so calling method on string throws null pointer exception");
		}

	}

}
