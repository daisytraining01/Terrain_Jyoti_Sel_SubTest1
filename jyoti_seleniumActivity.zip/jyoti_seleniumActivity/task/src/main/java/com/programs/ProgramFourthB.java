package com.programs;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProgramFourthB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "src/main/java/driver/chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//a) implicit wait 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//driver.get("http://demo.guru99.com/test/newtours/register.php");
		
		
        driver.get("http://demo.rapidtestpro.com/login.php");
		
		driver.findElement(By.id("accno")).sendKeys("1234556666");
		
		driver.findElement(By.id("pass")).sendKeys("MavDemo@01");
		
		driver.findElement(By.xpath("//input[@value='Login Now ! ']")).click();
		
		//b) explicit wait
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("accpin")));
		
		
		driver.findElement(By.id("accpin")).sendKeys("12345");
		
	
		
		driver.findElement(By.xpath("//*[@id=\"submitButton\"]")).click();

	}

}
