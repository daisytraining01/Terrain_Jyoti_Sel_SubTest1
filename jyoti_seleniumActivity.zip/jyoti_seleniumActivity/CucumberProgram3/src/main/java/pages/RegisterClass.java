package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterClass {
	
WebDriver driver;
	
	@FindBy(how=How.NAME, using="firstName")
	private WebElement fName;

	@FindBy(how=How.NAME, using="lastName")
	private WebElement lName;	
	
	@FindBy(how=How.NAME, using="phone")
	private WebElement phoneNo;

	@FindBy(how=How.NAME, using="userName")
	private WebElement userName;
	
	@FindBy(how=How.NAME, using="address1")
	private WebElement address;
	
	@FindBy(how=How.NAME, using="city")
	private WebElement city;
	
	@FindBy(how=How.NAME, using="state")
	private WebElement state;
	
	@FindBy(how=How.NAME, using="postalcode")
	private WebElement postalCode;
	
	@FindBy(how=How.ID, using="email")
	private WebElement email;
	
	@FindBy(how=How.NAME, using="password")
	private WebElement password;
	
	@FindBy(how=How.NAME, using="confirmPassword")
	private WebElement conPassword;
	
	@FindBy(how=How.NAME, using="submit")
	private WebElement submitBotton;
	
	
	public void setFirstName(String name) {
		fName.sendKeys(name);
	}

	public void seLastName(String name) {
		lName.sendKeys(name);
	}
	
	public void setPhoneNum(String phoneNum) {
		phoneNo.sendKeys(phoneNum);
	}
	
	public void setUserName(String name) {
		userName.sendKeys(name);
	}
	
	public void setAddress(String add) {
		address.sendKeys(add);
	}
	
	public void setCity(String cityName) {
		city.sendKeys(cityName);
	}
	public void setState(String stateName) {
		state.sendKeys(stateName);		
	}

   public void setEmail(String emailAdd) {
	   email.sendKeys(emailAdd);
	}
   
   public void setPassword(String pass) {
	   password.sendKeys(pass);
	}
   
   public void setconfPassword(String confPass) {
	   conPassword.sendKeys(confPass);
	}
   
   public void setDropDown() {
		Select select=new Select(driver.findElement(By.name("country")));		   
		   select.selectByIndex(1);
		   }
   
   public void clickSubmitButton() {
	   submitBotton.click();
   }


   
	public RegisterClass(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

}



