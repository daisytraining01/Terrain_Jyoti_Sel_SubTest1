package stepdef;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import pages.RegisterClass;

import utility.SettingBrowerAndURL;

public class Steps {

	SettingBrowerAndURL st = new SettingBrowerAndURL("chrome");

	RegisterClass reg = new RegisterClass(st.driver);

	@When("User provides neccessary details for Register")
	public void user_provides_neccessary_details_for_Reg() throws IOException, InterruptedException {

		reg.setFirstName("priya");
		reg.seLastName("M");
		reg.setUserName("priya@gmail.com");
		reg.setPhoneNum("6789234567");
		reg.setAddress("kk colony");
		reg.setCity("banglore");
		reg.setState("UP");
		reg.setDropDown();
		reg.setEmail("priya@gmail.com");
		reg.setPassword("pass");
		reg.setconfPassword("pass");
		reg.clickSubmitButton();

	}

	@Then("User registered for given URL")
	public void user_clicks_Fund_Transfer_button() throws IOException, InterruptedException {
		reg.clickSubmitButton();
	}

}
